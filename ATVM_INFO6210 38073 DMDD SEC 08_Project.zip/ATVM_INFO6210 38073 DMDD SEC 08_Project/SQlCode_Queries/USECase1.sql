use universities;

Select * from `universities`.`top_100_univ`  where `Rank`  between 1 and 10;